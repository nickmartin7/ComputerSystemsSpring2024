# csci2271-a6-template
An assignment to implement a simple version of zip and unzip.
