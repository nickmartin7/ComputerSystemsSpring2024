# csci2271-a7-template
An assignment to write a simple version of malloc() and free().
