#define _XOPEN_SOURCE 500 // needed for sbrk() on cslab

#include <unistd.h>
typedef struct freenode
{
    size_t size;
    struct freenode *next;
} freenode;

#define HEAP_CHUNK_SIZE 4096

freenode *freelist = NULL;

/* allocate size bytes from the heap */
void *malloc(size_t size)
{    
    if (size < 1)
    {
        return NULL;
    }
    size+=8;

    if (size <32)
    {
        size = 32;
    }
    else if (size % 16 != 0){
        size = ((size/16) + 1) * 16;
    
    }
    freenode *prev = NULL;
    freenode *current = freelist;

    while (current != NULL && current->size < size) {
        prev = current;
        current = current->next;
    }

    if (current == NULL) {
        current = sbrk(HEAP_CHUNK_SIZE);
        if (current == (void *) -1) { // sbrk failed
            return NULL;
        }
        current->size = HEAP_CHUNK_SIZE;
        current->next = NULL;
        if (prev) {
            prev->next = current;
        } else {
            freelist = current;
        }
    }

    if (current->size - size < 32) {
        if (prev) {
            prev->next = current->next;
        } else {
            freelist = current->next;
        }
        return (char*)current + 8;
    } else {
        freenode *new_node = (freenode *)((char*)current + size);
        new_node->size = current->size - size;
        new_node->next = current->next;
        if (prev) {
            prev->next = new_node;
        } else {
            freelist = new_node;
        }
        current->size = size;
        return (char*)current + 8;
    }

}
/* return a previously allocated memory chunk to the allocator */
void free(void *ptr)
{
    if (ptr == NULL)
    {
        return;
    }

    // make a new freenode starting 8 bytes before the provided address
    freenode *new_node = (freenode *)(ptr-8);

    // the size is already in memory at the right location (ptr-8)

    // add this memory chunk back to the beginning of the freelist
    new_node->next = freelist;
    freelist = new_node;
    
    return;
}

