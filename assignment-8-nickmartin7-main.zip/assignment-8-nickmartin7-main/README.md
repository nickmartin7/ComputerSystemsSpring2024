# csci2271-a8-template
An assignment to write a rudimentary shell.
