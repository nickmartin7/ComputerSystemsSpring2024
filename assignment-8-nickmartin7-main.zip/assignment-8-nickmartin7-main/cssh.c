#define _POSIX_C_SOURCE 200809L // required for strdup() on cslab
#define _DEFAULT_SOURCE // required for strsep() on cslab
#define _BSD_SOURCE // required for strsep() on cslab

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>

#define MAX_ARGS 32

char **get_next_command(size_t *num_args)
{
    // print the prompt
    printf("cssh$ ");

    // get the next line of input
    char *line = NULL;
    size_t len = 0;
    getline(&line, &len, stdin);
    if (ferror(stdin))
    {
        perror("getline");
        exit(1);
    }
    if (feof(stdin))
    {
        return NULL;
    }

    // turn the line into an array of words
    char **words = (char **)malloc(MAX_ARGS*sizeof(char *));
    int i=0;

    char *parse = line;
    while (parse != NULL)
    {
        char *word = strsep(&parse, " \t\r\f\n");
        if (strlen(word) != 0)
        {
            words[i++] = strdup(word);
        }
    }
    *num_args = i;
    for (; i<MAX_ARGS; ++i)
    {
        words[i] = NULL;
    }

    // all the words are in the array now, so free the original line
    free(line);

    return words;
}

void free_command(char **words)
{
    for (int i=0; i<MAX_ARGS; ++i)
    {
        if (words[i] == NULL)
        {
            break;
        }
        free(words[i]);
    }
    free(words);
}
//This function chcks for multiple redirection errors
int check_redirection_errors(char **command_line_words) {
    int input_redirection_count = 0;
    int output_redirection_count = 0;

    for (int i = 0; command_line_words[i] != NULL; i++) {
        if (strcmp(command_line_words[i], "<") == 0) {
            input_redirection_count++;
        } else if (strcmp(command_line_words[i], ">") == 0 || strcmp(command_line_words[i], ">>") == 0) {
            output_redirection_count++;
        }
    }

    if (input_redirection_count > 1) {
        fprintf(stderr, "Error! Can't have two <'s!\n");
        return 1;
    } else if (output_redirection_count > 1) {
        fprintf(stderr, "Error! Can't have two >'s or >>'s!\n");
        return 1;
    }

    return 0;
}
void handle_io_redirection(char **command_line_words) {
    for (int i = 0; command_line_words[i] != NULL; i++) {
        if (strcmp(command_line_words[i], "<") == 0 && command_line_words[i + 1] != NULL) {
            int fd = open(command_line_words[i + 1], O_RDONLY);
            if (fd == -1) {
                perror("open");
                exit(EXIT_FAILURE);
            }
            dup2(fd, STDIN_FILENO);
            close(fd);
            command_line_words[i] = NULL;
        } else if ((strcmp(command_line_words[i], ">") == 0 || strcmp(command_line_words[i], ">>") == 0) && command_line_words[i + 1] != NULL) {
            int flags = (strcmp(command_line_words[i], ">") == 0) ? (O_WRONLY | O_CREAT | O_TRUNC) : (O_WRONLY | O_CREAT | O_APPEND);
            int fd = open(command_line_words[i + 1], flags, 0644);
            if (fd == -1) {
                perror("open");
                exit(EXIT_FAILURE);
            }
            dup2(fd, STDOUT_FILENO);
            close(fd);
            command_line_words[i] = NULL;
        }
    }
}

//This function excutes the command
void execute_command(char **command_line_words) {
    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
    } else if (pid == 0) {
        handle_io_redirection(command_line_words);
        execvp(command_line_words[0], command_line_words);
        perror("execvp");
        exit(EXIT_FAILURE);
    } else {
        int status;
        waitpid(pid, &status, 0);
    }
    free_command(command_line_words);
}
int main() {
    size_t num_args;
    char **command_line_words = get_next_command(&num_args);

    while (command_line_words != NULL) {
        if (num_args == 0) {
            free_command(command_line_words);
        } else if (strcmp(command_line_words[0], "exit") == 0) {
            free_command(command_line_words);
            break;
        } else {
            if (!check_redirection_errors(command_line_words)) {
                execute_command(command_line_words);
            }
        }
        command_line_words = get_next_command(&num_args);
    }

    return 0;
}
